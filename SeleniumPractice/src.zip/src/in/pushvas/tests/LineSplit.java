package in.pushvas.tests;

public class LineSplit {

	public static void main(String[] args) {
		
		
		String line = "Suresh.kumar.chirra";
		String[] fn = line.split("\\."); 
		System.out.println("Size : "+fn.length);

	}

}
